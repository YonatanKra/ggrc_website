<?php
/** no direct access **/
defined('MECEXEC') or die();

/**
 * Webnus MEC controller class.
 * @author Webnus <info@webnus.biz>
 */
class MEC_controller extends MEC_base
{
    /**
     * Constructor method
     * @author Webnus <info@webnus.biz>
     */
    public function __construct()
    {
    }
}