<?php
/** no direct access **/
defined('MECEXEC') or die();
?>
<div class="mec-profile-message">
    <p><?php echo $message; ?></p>
</div>